#include <iostream>
using namespace std;

int main() {
    cout << "Hello to the c++ World!" << endl;
    return 0;
}

