#include <stdio.h>

int main() {
    printf("Hello to the C Language world!\n");
    return 0;
}

